const express = require('express');
const router = express.Router();
const Post = require('../models/post');





/**
 * GET /
 * HOME
*/
router.get('', async (req, res) => {
  try {
    const locals = {
      title: "NodeJs Blog",
      description: "Simple Blog created with NodeJs, Express & MongoDb."
    }

    let perPage = 10;
    let page = req.query.page || 1;

    const data = await Post.aggregate([ { $sort: { createdAt: -1 } } ])
    .skip(perPage * page - perPage)
    .limit(perPage)
    .exec();

    // Count is deprecated - please use countDocuments
    // const count = await Post.count();
    const count = await Post.countDocuments({});
    const nextPage = parseInt(page) + 1;
    const hasNextPage = nextPage <= Math.ceil(count / perPage);

    res.render('index', { 
      locals,
      data,
      current: page,
      nextPage: hasNextPage ? nextPage : null,
      currentRoute: '/'
    });

  } catch (error) {
    console.log(error);
  }

});



/**
 * GET /
 * Post :id
*/
router.get('/post/:id', async (req, res) => {
  try {
    const postData = await Post.findById(req.params.id);
    res.render('post', { data: postData, user: req.user });
  } catch (err) {
    console.error(err);
    res.status(500).send("Server Error");
  }
});



/**
 * POST /
 * Post - searchTerm
*/
router.post('/search', async (req, res) => {
  try {
    const locals = {
      title: "Seach",
      description: "Simple Blog created with NodeJs, Express & MongoDb."
    }

    let searchTerm = req.body.searchTerm;
    const searchNoSpecialChar = searchTerm.replace(/[^a-zA-Z0-9 ]/g, "")

    const data = await Post.find({
      $or: [
        { title: { $regex: new RegExp(searchNoSpecialChar, 'i') }},
        { body: { $regex: new RegExp(searchNoSpecialChar, 'i') }}
      ]
    });

    res.render("search", {
      data,
      locals,
      currentRoute: '/'
    });

  } catch (error) {
    console.log(error);
  }

});

/**
 * POST /post/:id/comment
 * Add a Comment to a Post
 */
router.post('/post/:id/comment', async (req, res) => {
  try {
    const { username, comment, deleteKey } = req.body; // Accept deleteKey input
    const postId = req.params.id;

    const newComment = {
      username: username || 'Anonymous',
      comment,
      deleteKey,
      createdAt: new Date()
    };

    await Post.findByIdAndUpdate(postId, {
      $push: { comments: newComment }
    });

    res.redirect(`/post/${postId}`);
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});



router.get('/post/:id', async (req, res) => {
  try {
    let slug = req.params.id;

    const data = await Post.findById({ _id: slug });

    if (!data) {
      return res.status(404).send("Post not found");
    }

    // Ensure 'comments' property exists
    data.comments = data.comments || [];

    const locals = {
      title: data.title || "Post",
      description: "Simple Blog created with NodeJs, Express & MongoDb.",
    };

    res.render('post', { 
      locals,
      data,
      currentRoute: `/post/${slug}`
    });
  } catch (error) {
    console.log(error);
    res.status(500).send("Server Error");
  }
});

router.post('/post/:postId/comment/:commentId/delete', async (req, res) => {
  try {
    const { postId, commentId } = req.params;
    const { deleteKey } = req.body;

    // Find the post and ensure the deleteKey matches
    const post = await Post.findOne({ _id: postId, 'comments._id': commentId });

    if (!post) {
      return res.status(404).json({ error: 'Post or comment not found' });
    }

    const comment = post.comments.id(commentId);
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }

    // Validate the delete key
    if (comment.deleteKey !== deleteKey) {
      return res.status(401).json({ error: 'Invalid delete key' });
    }

    // Remove the comment using $pull
    await Post.findByIdAndUpdate(postId, {
      $pull: { comments: { _id: commentId } }
    });

    res.redirect(`/post/${postId}`); // Redirect back to the post page
  } catch (error) {
    console.error("Error occurred:", error);
    res.status(500).json({ error: 'Server Error' });
  }
});








/**
 * GET /
 * About
*/
router.get('/about', (req, res) => {
  res.render('about', {
    currentRoute: '/about'
  });
});

router.get('/contact', (req, res) => {
  res.render('contact', {
    currentRoute: '/contact'
  });
});







module.exports = router;