const express = require('express');
const router = express.Router();
const Post = require('../models/post');
const User = require('../models/user');
require('dotenv').config(); // Load environment variables
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');


const multer = require('multer');
const path = require('path');

// Set Storage Engine
const storage = multer.diskStorage({
  destination: './public/uploads/', // Directory to store uploaded files
  filename: (req, file, cb) => {
    cb(null, `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`);
  },
});

// File Type Filter (Only videos)
const fileFilter = (req, file, cb) => {
  const filetypes = /mp4|mov|avi|mkv/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = file.mimetype.startsWith('video');

  if (extname && mimetype) {
    return cb(null, true);
  } else {
    cb('Error: Only video files are allowed (mp4, mov, avi, mkv)');
  }
};

const upload = multer({
  storage: storage,
  limits: { fileSize: 100000000 }, // 100 MB limit
  fileFilter: fileFilter,
});

const adminLayout = '../views/layouts/admin';
const jwtSecret = process.env.JWT_SECRET;

//for password protection
const authMiddleware = (req, res, next) => {
  const token = req.cookies.token; // Ensure cookie-parser is enabled
  if (token) {
    try {
      const decoded = jwt.verify(token, jwtSecret);
      req.user = decoded; // Attach user data to the request object
    } catch (err) {
      req.user = null; // Token invalid or expired
    }
  } else {
    req.user = null; // No token provided
  }
  next();
};




router.post('/admin', async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await User.findOne({ username });

    if (!user) {
      return res.status(401).json({ message: 'Invalid User' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user._id }, jwtSecret);
    res.cookie('token', token, { httpOnly: true });
    res.redirect('/dashboard');

  } catch (error) {
    console.log(error);
  }
});







router.get('/dashboard', authMiddleware, async (req, res) => {
  try {
    const locals = {
      title: 'Dashboard',
      description: 'Simple Blog created with NodeJs, Express & MongoDb.'
    }

    const data = await Post.find();
    res.render('admin/dashboard', {
      locals, 
      data,
      layout: adminLayout
    });

  } catch (error) {

  }


});


router.get('/add-post', authMiddleware, async (req, res) => {
  try {
    const locals = {
      title: 'Add Post',
      description: 'Simple Blog created with NodeJs, Express & MongoDb.'
    };

    res.render('admin/add-post', {
      locals,
      layout: adminLayout // Make sure this layout exists
    });
  } catch (error) {
    console.log(error);
    res.status(500).send('Server Error');
  }
});




/**
 * GET /
 * Admin - Login Page
*/
router.get('/admin', async (req, res) => {
  try {
    const locals = {
      title: "Admin",
      description: "Simple Blog created with NodeJs, Express & MongoDb."
    }

    res.render('admin/index', { locals, layout: adminLayout });
  } catch (error) {
    console.log(error);
  }
});



router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
      // Create the user
      const user = await User.create({ username, password: hashedPassword });
      
      // Redirect to another page if successful
      res.redirect('/dashboard'); // Replace with your desired route
    } catch (error) {
      if (error.code === 11000) {
        // Handle duplicate username error
        res.status(409).render('admin/register', {
          errorMessage: 'User already exists. Please try another username.',
          title: 'Register',
        });
      } else {
        console.log(error);
        res.status(500).render('admin/error', {
          errorMessage: 'Internal Server Error. Please try again later.',
        });
      }
    }

  } catch (error) {
    console.log(error);
    res.status(500).render('admin/error', {
      errorMessage: 'Server Error. Please try again.',
    });
  }
});


router.post('/add-post', authMiddleware, upload.single('video'), async (req, res) => {
  try {
    const newPost = new Post({
      title: req.body.title,
      body: req.body.body,
      video: req.file ? `/uploads/${req.file.filename}` : null, // Store video path
    });

    await Post.create(newPost);
    res.redirect('/dashboard');
  } catch (error) {
    console.log(error);
    res.status(500).send('Server Error');
  }
});



router.get('/edit-post/:id', authMiddleware, async (req, res) => {
  try {

    const locals = {
      title: "Edit Post",
      description: "Free NodeJs User Management System",
    };

    const data = await Post.findOne({ _id: req.params.id });

    res.render('admin/edit-post', {
      locals,
      data,
      layout: adminLayout
    })

  } catch (error) {
    console.log(error);
  }

});

router.put('/edit-post/:id', authMiddleware, async (req, res) => {
  try {

    await Post.findByIdAndUpdate(req.params.id, {
      title: req.body.title,
      body: req.body.body,
      updatedAt: Date.now()
    });

    res.redirect(`/edit-post/${req.params.id}`);

  } catch (error) {
    console.log(error);
  }

});

router.post('/post/:id/comment', async (req, res) => {
  try {
    const postId = req.params.id;
    const { username, comment } = req.body;

    // Default username to 'Anonymous' if empty
    const commentData = {
      username: username || 'Anonymous',
      comment: comment,
      createdAt: new Date()
    };

    // Find the post and update its comments
    await Post.findByIdAndUpdate(postId, { 
      $push: { comments: commentData } 
    });

    res.redirect(`/post/${postId}`); // Redirect back to the post page
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

router.post('/search', async (req, res) => {
  try {
    const locals = {
      title: "Seach",
      description: "Simple Blog created with NodeJs, Express & MongoDb."
    }

    let searchTerm = req.body.searchTerm;
    const searchNoSpecialChar = searchTerm.replace(/[^a-zA-Z0-9 ]/g, "")

    const data = await Post.find({
      $or: [
        { title: { $regex: new RegExp(searchNoSpecialChar, 'i') }},
        { body: { $regex: new RegExp(searchNoSpecialChar, 'i') }}
      ]
    });

    res.render("search", {
      data,
      locals,
      currentRoute: '/'
    });

  } catch (error) {
    console.log(error);
  }

});














module.exports = router;