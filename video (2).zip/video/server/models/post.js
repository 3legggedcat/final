const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
  title: String,
  body: String,
  video: String,
  comments: [
    {
      username: { type: String, default: 'Anonymous' },
      comment: { type: String, required: true },
      deleteKey: { type: String, required: true }, // Key to delete the comment
      createdAt: { type: Date, default: Date.now }
    }
  ],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Post', PostSchema);



